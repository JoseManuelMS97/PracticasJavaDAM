package autoeval8;

public class main {

	public static void main(String[] args) {
		Proveedor p = new Proveedor();
		System.out.println(p.toString());
	}

}
